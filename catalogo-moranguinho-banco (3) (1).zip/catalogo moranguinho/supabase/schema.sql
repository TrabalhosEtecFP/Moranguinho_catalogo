-- ============================================================
--  MORANGUINHO — esquema do banco (Supabase / PostgreSQL)
--  Rode este arquivo inteiro no SQL Editor do Supabase, UMA vez.
--  Depois rode o seed.sql (dados iniciais).
-- ============================================================

-- ---------- Tabelas ----------
create table if not exists public.categorias (
  id      text primary key check (id ~ '^[a-z0-9_-]+$'),
  nome    text not null check (length(trim(nome)) > 0),
  nota    text not null default '',
  unidade text not null default '',
  ordem   int  not null default 0
);

create table if not exists public.produtos (
  id            uuid primary key default gen_random_uuid(),
  categoria_id  text not null references public.categorias(id) on update cascade on delete restrict,
  nome          text not null check (length(trim(nome)) > 0),
  descricao     text not null default '',
  preco         numeric(10,2) not null check (preco >= 0),
  preco_antigo  numeric(10,2) check (preco_antigo >= 0),
  imagem        text,                         -- nome de arquivo em /bolos ou URL completa (fotos enviadas pelo painel)
  ordem         int  not null default 0,
  ativo         boolean not null default true, -- false = escondido do site
  atualizado_em timestamptz not null default now()
);
create index if not exists produtos_categoria_ordem on public.produtos (categoria_id, ordem);

-- Textos do site (título, rodapé, lojas, WhatsApp...)
create table if not exists public.config (
  chave text primary key,
  valor text not null default ''
);

-- Quem pode editar. Só quem estiver nesta tabela consegue gravar, mesmo que tenha login.
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

-- Atualiza "atualizado_em" automaticamente
create or replace function public.tg_atualizado_em() returns trigger
language plpgsql as $$
begin
  new.atualizado_em := now();
  return new;
end $$;

drop trigger if exists produtos_atualizado_em on public.produtos;
create trigger produtos_atualizado_em before update on public.produtos
  for each row execute function public.tg_atualizado_em();

-- ---------- Função "é administrador?" ----------
create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------- Segurança (RLS): visitantes só LEEM; só admin ESCREVE ----------
alter table public.categorias enable row level security;
alter table public.produtos   enable row level security;
alter table public.config     enable row level security;
alter table public.admins     enable row level security;   -- sem política = ninguém lê pela API

drop policy if exists "categorias: todos leem"    on public.categorias;
drop policy if exists "categorias: admin escreve" on public.categorias;
create policy "categorias: todos leem"    on public.categorias for select to anon, authenticated using (true);
create policy "categorias: admin escreve" on public.categorias for all    to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "produtos: todos leem ativos" on public.produtos;
drop policy if exists "produtos: admin tudo"        on public.produtos;
create policy "produtos: todos leem ativos" on public.produtos for select to anon, authenticated using (ativo);
create policy "produtos: admin tudo"        on public.produtos for all    to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "config: todos leem"    on public.config;
drop policy if exists "config: admin escreve" on public.config;
create policy "config: todos leem"    on public.config for select to anon, authenticated using (true);
create policy "config: admin escreve" on public.config for all    to authenticated using (public.is_admin()) with check (public.is_admin());

-- Permissões de tabela (a RLS acima é quem decide de fato)
grant select on public.categorias, public.produtos, public.config to anon, authenticated;
grant insert, update, delete on public.categorias, public.produtos, public.config to authenticated;

-- ---------- Fotos enviadas pelo painel (Storage) ----------
insert into storage.buckets (id, name, public)
values ('fotos', 'fotos', true)
on conflict (id) do nothing;

drop policy if exists "fotos: todos veem"       on storage.objects;
drop policy if exists "fotos: admin envia"      on storage.objects;
drop policy if exists "fotos: admin altera"     on storage.objects;
drop policy if exists "fotos: admin apaga"      on storage.objects;
create policy "fotos: todos veem"   on storage.objects for select to anon, authenticated using (bucket_id = 'fotos');
create policy "fotos: admin envia"  on storage.objects for insert to authenticated with check (bucket_id = 'fotos' and public.is_admin());
create policy "fotos: admin altera" on storage.objects for update to authenticated using (bucket_id = 'fotos' and public.is_admin());
create policy "fotos: admin apaga"  on storage.objects for delete to authenticated using (bucket_id = 'fotos' and public.is_admin());

-- ============================================================
--  DEPOIS de criar o usuário no painel do Supabase
--  (Authentication > Users > Add user), rode ISTO trocando o e-mail:
--
--    insert into public.admins (user_id)
--    select id from auth.users where email = 'SEU-EMAIL@exemplo.com';
-- ============================================================
