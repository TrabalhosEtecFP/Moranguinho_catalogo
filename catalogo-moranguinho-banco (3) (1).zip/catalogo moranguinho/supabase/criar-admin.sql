-- Libera o e-mail abaixo como administrador do painel.
-- Rode DEPOIS de criar o usuário em: Authentication > Users > Add user
-- (a senha é definida lá, nunca neste arquivo).
insert into public.admins (user_id)
select id from auth.users where email = 'matheusbertolai3@gmail.com'
on conflict (user_id) do nothing;

-- Conferir (deve aparecer 1 linha):
-- select u.email from public.admins a join auth.users u on u.id = a.user_id;
